// ***** 0. Documentation Section *****
// SwitchLEDInterface.c for Lab 8
// Runs on LM4F120/TM4C123
// Use simple programming structures in C to toggle an LED
// while a button is pressed and turn the LED on when the
// button is released.  This lab requires external hardware
// to be wired to the LaunchPad using the prototyping board.
// Febuary 16, 2018
//      Tolulope Ademilua
// ***** 1. Pre-processor Directives Section *****

//USING Address to access Register

#include "TExaS.h"
#include "tm4c123gh6pm.h"

volatile unsigned long PE0;
volatile unsigned long PE1;
void Delay100ms (unsigned long time);
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
void Delay100ms (unsigned long time){
  while(time > 0){
	unsigned long counter; 
	counter = 1333333; //this means 100ms
   while (counter > 0 ) {
           --counter;
        }
				 --time;   //decrements every 100ms
	}
}
int main(void) {
     volatile unsigned long delay;
     SYSCTL_RCGC2_R |= 0x00000010;     // 1) 	E clock
     delay = SYSCTL_RCGC2_R; 
	   //
     *((volatile unsigned long*)0x40024400)=  0x02;   //  PE0 input, PE1 output  
     *((volatile unsigned long *)0x4002451C)= 0x03;   //  enable digital pins PE0-PE1; GPIO_PORTE_DEN_R = 0x03;  
     *((volatile unsigned long *)0x40024524)= 0x1F;   //  allow changes to PE; GPIO_PORTE_CR_R = 0x1F;
	   *((volatile unsigned long *)0x40024528)= 0x00;   //  disable analog function; GPIO_PORTE_AMSEL_R = 0x00;  
	   *((volatile unsigned long *)0x40024510)= 0x00;   //  GPIO_PORTE_PUR_R = 0x00; 00 enable pullup resistors on PE0,PE1: no need because we use positive logic, external and our resistor uses 10kohms  
	   *((volatile unsigned long *)0x4002452C)= 0x00000000; //GPIO_PORTE_PCTL_R = 0x00000000;  GPIO clear bit PCTL 
    while (1){
			PE0 = *((volatile unsigned long*)0x40024004)&0x01;
	  if(PE0){ 
			*((volatile unsigned long *)0x40024008)= 0x02; // the base address of portE + the constant value PE1 =0x40024008, accessed PE1 
					 Delay100ms(1);
		  *((volatile unsigned long*)0x40024008)= 0x00;
        	Delay100ms(1);
		}else{
				*((volatile unsigned long *)0x40024008)=0x02;
				}
       
    }
}


//USING GPIO name to access Register

//#define PE1 (*((volatile *)0x40024008))
//#define PE0 (*((volatile *)0x40024004))
//// ***** 2. Global Declarations Section *****
////unsigned long PE0;  // input from PE0
////unsigned long PE1;      // outputs to PE1 (multicolor LED)
// 
//// FUNCTION PROTOTYPES: Each subroutine defined
//void PortE_Init(void);
//void Delay(void);
//void DisableInterrupts(void); // Disable interrupts
//void EnableInterrupts(void);  // Enable interrupts
//// function to delay for 100ms
//void Delay100ms(unsigned long time){
//  unsigned long i;
//  while(time > 0){
//    i = 1333333;  // this number means 100ms
//    while(i > 0){
//      i = i - 1;
//    }
//    time = time - 1; // decrements every 100 ms
//  }
//}


//int main(void){ 
////**********************************************************************
//// The following version tests input on PE0 and output on PE1
////**********************************************************************
//  TExaS_Init(SW_PIN_PE0, LED_PIN_PE1, ScopeOn);  // activate grader and set system clock to 80 MHz
//  
//	PortE_Init();   
//  EnableInterrupts();           // enable interrupts for the grader
// while(1){
//	PE0 = GPIO_PORTE_DATA_R&0x01;
//	 if(PE0){ 
//      //Using 5hz that means Switch is pressed and LED should toggle each 100ms	from off to on and vice versa	 
//		   GPIO_PORTE_DATA_R = 0x00; //Off PE1
//		   Delay100ms(1);            // Set delay for 100ms
//		   GPIO_PORTE_DATA_R = 0x02; // On PE1
//		   Delay100ms(1);            // set delay for 100ms
//  }else{
//		 GPIO_PORTE_DATA_R = 0x02;    //Switch not pressed Led should be on
//			 }
//  }
//  
//  
//}
//void PortE_Init(void){ 
//	volatile unsigned long delay;
//  SYSCTL_RCGC2_R |= 0x00000010;     // 1) 	E clock
//  delay = SYSCTL_RCGC2_R;           // delay   
//  GPIO_PORTE_LOCK_R = 0x4C4F434B;  // 2) unlock PortE PE0  
//  GPIO_PORTE_CR_R = 0x1F;           // allow changes to PE      
//  GPIO_PORTE_AMSEL_R = 0x00;        // 3) disable analog function
//  GPIO_PORTE_PCTL_R = 0x00000000;   // 4) GPIO clear bit PCTL  
//  GPIO_PORTE_DIR_R = 0x02;          // 5) PE0 input, PE1 output   
//  GPIO_PORTE_AFSEL_R = 0x00;        // 6) no alternate function
//  GPIO_PORTE_PUR_R = 0x00;          // enable pullup resistors on PE0,PE1       
//  GPIO_PORTE_DEN_R = 0x03;          // 7) enable digital pins PE0-PE1  
//	//GPIO_PORTE_DATA_R = 0x02;       // putting FE1 to be initially on
//}
// ***** 3. Subroutines Section *****

// PE0, PB0, or PA2 connected to positive logic momentary switch using 10k ohm pull down resistor
// PE1, PB1, or PA3 connected to positive logic LED through 470 ohm current limiting resistor
// To avoid damaging your hardware, ensure that your circuits match the schematic
// shown in Lab8_artist.sch (PCB Artist schematic file) or 
// Lab8_artist.pdf (compatible with many various readers like Adobe Acrobat).

//1) Make PE1 an output and make PE0 an input. 
//2) The system starts with the LED on (make PE1 =1). 
//3) Wait about 100 ms
//4) If the switch is pressed (PE0 is 1), then toggle the LED once, else turn the LED on. 
//5) Steps 3 and 4 are repeated over and over.
